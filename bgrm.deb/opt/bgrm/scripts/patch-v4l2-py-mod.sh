#!/bin/bash

# Author: Dylan Turner
# Description: Patches v4l2 python module to work with modern python

cp scripts/v4l2\ \(patch\).py .venv/lib/python3.9/site-packages/v4l2.py
